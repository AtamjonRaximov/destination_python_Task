// URL API
const baseUrl = " http://127.0.0.1:5000";

// Элементы DOM
const deleteFile = document.querySelector("#deleteFileBtn");
const renameFile = document.querySelector("#renameFileBtn");
const backwardBtn = document.querySelector("#backwardBtn");
const forwardBtn = document.querySelector("#forwardBtn");
const pathInput = document.querySelector(".folder-path-input");
const container = document.querySelector(".filemanager-container-row");
const homeBtn = document.querySelector("#homeBtn");
const createFileBtn = document.querySelector("#createFileBtn");
let clipboard = null; // Объект для хранения информации о копируемом/вырезаемом элементе
let isCutAction = false; // Флаг для определения действия: копирование или вырезание

// Функция для отправки запроса на изменение папки
async function changeFolder(newFolder) {
  try {
    const response = await fetch(`${baseUrl}/change-folder`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ folder: newFolder }),
    });

    if (!response.ok) {
      throw new Error(`Ошибка при изменении папки: ${response.status}`);
    }

    const data = await response.json();

    // Загружаем содержимое новой директории
    fetchContents(`${baseUrl}/files`);
  } catch (error) {
    console.error("Ошибка:", error);
  }
}

// Функция для определения типа элемента (файл или папка)
function determineType(item) {
  const fileExtensions = ["pdf", "html", "jpg", "zip", "txt", "svg"];
  const extension = item.split(".").pop().toLowerCase();
  return fileExtensions.includes(extension) ? "file" : "folder";
}

// Функция для определения цвета и стиля иконки файла
function getFileIconProperties(fileType) {
  const icons = {
    pdf: { color: "247, 72, 72", label: "PDF" },
    html: { color: "36, 230, 149", label: "HTML" },
    jpg: { color: "255, 193, 7", label: "JPG" },
    zip: { color: "190, 173, 16", label: "ZIP" },
    txt: { color: "116, 116, 116", label: "TXT" },
    svg: { color: "36, 230, 149", label: "SVG" },
    default: { color: "116, 116, 116", label: "?" },
  };

  return icons[fileType.toLowerCase()] || icons.default;
}

// Функция для создания элемента папки
function createFolderElement(folderName) {
  const folderElement = document.createElement("div");
  folderElement.className = "folder";

  folderElement.innerHTML = `
    <div class="folder-icon-container">
      <div class="folder-icon"></div>
    </div>
    <p class="folder-name">${folderName}</p>
  `;

  // Обработчик клика для смены папки
  folderElement.addEventListener("dblclick", () => {
    changeFolder(folderName);
  });

  return folderElement;
}

// Функция для создания элемента файла
function createFileElement(fileName) {
  const fileType = fileName.split(".").pop();
  const { color, label } = getFileIconProperties(fileType);

  const fileElement = document.createElement("div");
  fileElement.className = "file";

  fileElement.innerHTML = `
    <div class="doc-icon-container">
      <div class="doc-icon" style="--icon-color: ${color}">
        <p>${label}</p>
      </div>
    </div>
    <p class="file-name" title="${fileName}">${fileName}</p>
  `;

  return fileElement;
}

// Функция для отрисовки содержимого директории
function renderContents(contents) {
  container.innerHTML = ""; // Очищаем контейнер

  contents.forEach((item) => {
    const itemType = determineType(item); // Определяем тип элемента

    if (itemType === "folder") {
      const folderElement = createFolderElement(item);
      container.appendChild(folderElement);
    } else {
      const fileElement = createFileElement(item);
      container.appendChild(fileElement);
    }
  });
}

// Функция для загрузки содержимого директории
async function fetchContents(url) {
  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ошибка! Статус: ${response.status}`);
    }

    const data = await response.json();

    pathInput.value = data.current_folder; // Устанавливаем текущую директорию
    renderContents(data.contents); // Отрисовываем содержимое
  } catch (error) {
    console.error("Ошибка:", error);
    alert("Не удалось загрузить содержимое директории. Попробуйте позже.");
  }
}

// Функция для создания нового файла
async function createFile(directory, fileName, content) {
  try {
    const response = await fetch(`${baseUrl}/create-file`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        directory: directory,
        file_name: fileName,
        content: content,
      }),
    });

    if (!response.ok) {
      if (response.status === 400) {
        alert("Ошибка: Имя файла или содержимое отсутствует.");
      }
      throw new Error(`Ошибка при создании файла: ${response.status}`);
    }

    const data = await response.json();

    // Обновляем содержимое текущей директории
    fetchContents(`${baseUrl}/files`);
  } catch (error) {
    console.error("Ошибка:", error);
    alert("Не удалось создать файл. Попробуйте позже.");
  }
}

// Обработчик для кнопки "Назад"
backwardBtn.addEventListener("click", () => {
  const currentPath = pathInput.value;

  // Получаем путь к родительской директории
  const parentPath = currentPath.split("/").slice(0, -1).join("/") || "/";

  changeFolder(parentPath);
});
homeBtn.addEventListener("click", () => {
  changeFolder("/");
});
// Обработчик для кнопки "Создать файл"
createFileBtn.addEventListener("dblclick", () => {
  const currentPath = pathInput.value; // Текущая директория
  const fileName = prompt("Введите имя файла (с расширением):", "example.txt");
  const content = prompt("Введите содержимое файла:", "Текст нового файла");

  if (fileName && content) {
    createFile(currentPath, fileName, content);
  } else {
    alert("Имя файла и содержимое не должны быть пустыми.");
  }
});
// Функция для создания новой папки
async function createFolder(folderName) {
  try {
    const response = await fetch(`${baseUrl}/create-folder`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ folder: folderName }),
    });

    if (!response.ok) {
      if (response.status === 400) {
        const errorData = await response.json();
        alert(`Ошибка: ${errorData.error}`);
      }
      throw new Error(`Ошибка при создании папки: ${response.status}`);
    }

    const data = await response.json();

    // Обновляем содержимое текущей директории
    fetchContents(`${baseUrl}/files`);
  } catch (error) {
    console.error("Ошибка:", error);
    alert("Не удалось создать папку. Попробуйте позже.");
  }
}

// Обработчик для кнопки "Создать папку"
document.querySelector("#createFolderBtn").addEventListener("click", () => {
  const folderName = prompt("Введите имя папки:");
  if (folderName) {
    createFolder(folderName);
  } else {
    alert("Имя папки не должно быть пустым.");
  }
});
// Инициализация загрузки содержимого
fetchContents(`${baseUrl}/files`);
// ////////////
let selectedItem = null; // Сохраняем выбранный файл или папку

// Выбор файла или папки
container.addEventListener("click", (e) => {
  const target = e.target.closest(".file, .folder");
  if (!target) return;

  // Снимаем выделение с других элементов
  document.querySelectorAll(".file, .folder").forEach((item) => {
    item.classList.remove("selected");
  });

  // Добавляем класс выделения
  target.classList.add("selected");

  // Определяем, файл или папка выбрана
  if (target.classList.contains("file")) {
    selectedItem = {
      type: "file",
      name: target.querySelector(".file-name").innerText,
    };
  } else if (target.classList.contains("folder")) {
    selectedItem = {
      type: "folder",
      name: target.querySelector(".folder-name").innerText,
    };
  }
});

//Удаление файла или папки
deleteFile.addEventListener("click", async () => {
  if (!selectedItem) {
    alert("Выберите файл или папку для удаления.");
    return;
  }

  try {
    const response = await fetch(`${baseUrl}/delete`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        target: selectedItem.name,
      }),
    });

    if (response.status === 200) {
      alert(
        `${selectedItem.type === "file" ? "Файл" : "Папка"} успешно удалён!`
      );
      // Обновляем содержимое директории
      fetchContents(`${baseUrl}/files`);
    } else if (response.status === 404) {
      alert(`${selectedItem.type === "file" ? "Файл" : "Папка"} не найден!`);
    } else {
      throw new Error(`Ошибка: ${response.status}`);
    }
  } catch (error) {
    console.error("Ошибка удаления:", error);
    alert("Не удалось удалить элемент. Попробуйте позже.");
  }
});
// Переименование файла или папки
renameFile.addEventListener("click", async () => {
  if (!selectedItem) {
    alert("Выберите файл или папку для переименования.");
    return;
  }

  const newName = prompt(
    `Введите новое имя для ${
      selectedItem.type === "file" ? "файла" : "папки"
    }:`,
    selectedItem.name
  );

  if (!newName) {
    alert("Новое имя не должно быть пустым.");
    return; // Выход из функции
  }

  try {
    const response = await fetch(`${baseUrl}/rename`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        type: selectedItem.type,
        current_name: selectedItem.name,
        new_name: newName,
      }), // Обновляем содержимое директории
    });

    if (response.status === 200) {
      alert(
        `${
          selectedItem.type === "file" ? "Файл" : "Папка"
        } успешно переименован!`
      );
      fetchContents(`${baseUrl}/files`);
    } else if (response.status === 404) {
      // Обновляем содержимое директории
      alert(`${selectedItem.type === "file" ? "Файл" : "Папка"} не найден!`);
    } else {
      throw new Error(`Ошибка: ${response.status}`);
    }
  } catch (error) {
    console.error("Ошибка переименования:", error);
    alert("Не удалось переименовать элемент. Попробуйте позже.");
  }
});
// Функция для копирования файла или папки
// Функция для вырежения файла или папки
document.querySelector("#copyBtn").addEventListener("click", () => {
  if (!selectedItem) {
    alert("Выберите файл или папку для копирования.");
    return;
  }

  clipboard = pathInput.value + "/" + selectedItem.name; //{ ...selectedItem }; // Сохраняем выбранный элемент
  isCutAction = false; // Устанавливаем флаг на копирование
});
document.querySelector("#cutBtn").addEventListener("click", () => {
  if (!selectedItem) {
    alert("Выберите файл или папку для вырезания.");
    return;
  }

  clipboard = pathInput.value + "/" + selectedItem.name; //{ ...selectedItem }; // Сохраняем выбранный элемент
  isCutAction = true; // Устанавливаем флаг на вырезание
});
document.querySelector("#pasteBtn").addEventListener("click", async () => {
  if (!clipboard) {
    alert("Буфер обмена пуст. Сначала скопируйте или вырежьте элемент.");
    return;
  }

  try {
    const response = await fetch(`${baseUrl}/move-file`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        current_file_folder: clipboard,
        cut: isCutAction, // Указываем, это вырезание или копирование
        new_file_folder: pathInput.value, // Текущая директория
      }),
    });

    if (response.ok) {
      alert(
        `${clipboard.type === "file" ? "Файл" : "Папка"} успешно ${
          isCutAction ? "вырезан(а)" : "скопирован(а)"
        } и вставлен(а)!`
      );
      clipboard = null; // Очищаем буфер обмена
      isCutAction = false; // Сбрасываем флаг действия
      fetchContents(`${baseUrl}/files`); // Обновляем содержимое текущей директории
    } else {
      const errorData = await response.json();
      alert(`Ошибка: ${errorData.error || "Не удалось выполнить операцию."}`);
    }
  } catch (error) {
    console.error("Ошибка вставки:", error);
    alert("Не удалось выполнить операцию. Попробуйте позже.");
  }
});
